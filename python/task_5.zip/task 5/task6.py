sum=0
arr=[2,3,4,5,8,9]
for i in range(len(arr)):
    sum+=(arr[i])
d=sum/(len(arr))
print(d)  

