a=20
b=45
product=a*b 
if product>500:
    sum=a+b
    print("value is",sum)
else:
    print("value is",product)
