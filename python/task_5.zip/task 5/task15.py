mul=1
arr=[2,4,5,6,7,8]
for i in range(len(arr)):
    mul*=len(arr)
    print(mul) 

