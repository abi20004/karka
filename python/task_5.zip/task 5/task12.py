chr="i"
if chr=="a" or chr=="e" or chr=="i" or chr=="o" or chr=="u":
    print("chr is a vowel")
else:
    print("chr is consonant")