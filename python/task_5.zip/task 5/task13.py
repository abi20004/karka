for i in range(10,55):
    if (i%2)==0:
        print(i,"is even")
    else:
        print(i,"is odd")