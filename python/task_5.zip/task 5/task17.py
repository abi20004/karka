num1=20
num2=40
if (num1>num2):
    print("num 1 is greater")
else:
    print("num 2 is greater")