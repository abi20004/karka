input=[10,20,30,40,10]
if input[0]==input[4]:
    print(True)
else:
    print(False)