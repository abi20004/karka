mul=1
for i in range(1,23):
    mul*=i
    print(mul)
