num=3
for i in range(1,8):
    print("$"*i)

num=2
for i in range(1,6):
    print("##")