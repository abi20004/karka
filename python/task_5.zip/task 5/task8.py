for i in range(1,6):
    print(i)